<?php
/**
 * Created by PhpStorm.
 * User: Vovan
 * Date: 13.05.2016
 * Time: 10:25
 */echo 'VladT';