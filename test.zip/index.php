﻿<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">

    <title>Морской бой/Главная</title>
    <script src="jquery-1.12.3.js"></script>
    <link rel="stylesheet" href="main.css" type="text/css">


</head>

<body>
<?php
error_reporting(-1);
if(isset($_GET['page'])){
    echo $_GET['page'];
}else $_GET['page'] = 'main';
?>
<header>

    <div class="logotype">
        <div><img src="pict/logotype.png"></div>
        <div><img src="pict/logotxt.png"></div>
        <div id="txt">Морской бой</div>
    </div>

    <nav>
            <ul>
                <li><a href="index.php?page=main">Главная</a></li>
                <li><a href="index.php?page=project">О проекте</a></li>
                <li><a href="index.php?page=aboutus">Обо мне</a></li>
                <li><a href="http://sourceit.com.ua/">Курсы SourceIT</a></li>
                <li><a href="javascript/SetGame.html">Игра МБ</a></li>
                <li><a href="index.php?page="entering">Вход</a></li>
            </ul>
    </nav>

</header>

<?php
include $_GET['page'].'.php';

?>


<footer>
    <div style="margin-top: 0px">
        <nav>
            <ul>
                <li><a href="index.php?page=roles">Правила игры</a></li>
                <li><a href="index.php?page=forum">Форум</a></li>
                <li><a href="index.php?page=uselinks">Полезные ссылки</a></li>
                <li><a href="index.php?page=entering">Вход</a></li>
            </ul>
        </nav>
    </div>



<h1><b>Сайт разработал: Ткаченко Владимир, май 2016/<?date() ?><b/></h1>
</footer>

<a href="javascript/SetGame.html">Setfield2</a>
<a href="form/form.php">Example</a>



</body>
</html>
</html>

