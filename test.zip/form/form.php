<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<form action="register.php" method="">
    <div>Введите логин: <input type="text" name="login"></div>
    <div>Введите пароль<input type="password" name="password"></div>
    <input type="submit" name="submit" value="Отправить">



</form>

</body>
</html>
<?php
error_reporting(-1);


?>



































