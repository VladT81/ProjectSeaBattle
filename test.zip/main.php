<section>
    <div>
        <div>
            <div class="leftcontent">reklama</div>
            <div class="centercontent">
                <img src="pict/ship.png">
                <div class="center">
                    <pre>
                        Dcnedktybt

                    </pre>
                </div>

            </div>
            <div class="rightcontent">news</div>
        </div>
    </div>

</section>