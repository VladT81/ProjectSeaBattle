/**
 * Created by Vovan on 18.04.2016.
 */

function Ship (live, orientation, coordinat) {
    this.live = "live";
    this.orientation = "orientation";
    this.coordinat = "coordinat";
}
var Esminec = new Ship (4, "H");
var Linkor1 = new Ship (3, "H");
var Linkor2 = new Ship (3, "H");
var Corvet1 = new Ship (2, "H");
var Corvet2 = new Ship (2, "H");
var Corvet3 = new Ship (2, "H");
var Boat = new Ship (1);





    +380733124981